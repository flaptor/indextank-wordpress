IndexTank Wordpress plugin README.txt

Instructions:
* place indextank_client.php and indextank_search.php on your wp-content/plugins directory.
* Go to the plugins section of your WP Dashboard, and activate Indextank.
* Now, you need to configure it
    * In your dashboard, go to Tools -> Indextank Searching
    * Fill your API URL, and your index name. If you don't have them yet, you
     need to get an account at http://indextank.com/. After you got an
     account, you can create an index.
    * Press the Save changes button to save those parameters
* After you are all set, you can press the "Index all posts" button.

You are all set, now just query something on your blog sidebar.
